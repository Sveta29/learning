import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class chatDialog {

    public static void main(String[] args) throws IOException {
        List<String> answers;
        answers = SetFile("answers.txt");

        Scanner scanner = new Scanner(System.in);
        boolean isIgnore = false;
        Date startDate = new Date();
        SimpleDateFormat formatForStartDate = new SimpleDateFormat("yyyyMMddHHmmss");
        String absolutePathFile = formatForStartDate.format(startDate) + ".log";
        FileOutputStream logFile = new FileOutputStream(absolutePathFile, true);
        System.out.println(answers.get(0) + "\n");

        while (true) {
            String command = scanner.nextLine();
            if (isIgnore == false) {
                logFile.write(QuestionToLog(command).getBytes());
                if (command.equals("\"Stop talking\"")) {
                    isIgnore = true;
                }
                else if (command.equals("\"Goodbye\"")) {
                    break;
                }
                else if (command.startsWith("\"Use another file:")& command.endsWith("\"")) {
                    String[] commandSplit = command.split("file:");
                    String newPath = commandSplit[1].substring(1,commandSplit[1].length()-1);
                    answers = SetFile(newPath);
                }
                else {
                    String randomAns = answers.get((int)(Math.random()*(answers.size()-2))+1);
                    System.out.println(randomAns);
                    logFile.write(AnswerToLog(randomAns).getBytes());
                }
            }
            else if (isIgnore == true) {
                logFile.write(QuestionToLog(command).getBytes());
                if (command.equals("\"Start talking\"")) {
                    isIgnore = false;
                }
            }
        }
        answers = SetFile("answers.txt");
        System.out.println("\n" + answers.get(answers.size()-1));
        logFile.close();
    }


    private static String QuestionToLog(String s) {
        Date nowDate = new Date();
        return "< " + nowDate + " >" + " < Question: > " + s + "\n";
    }


    private static String AnswerToLog(String s) {
        Date nowDate = new Date();
        return "< " + nowDate + " >" + " < Answer: > " + s + "\n";
    }


    private static List<String> SetFile(String path) throws IOException{
        FileReader file = new FileReader(path);
        Scanner buffer = new Scanner(file);
        List<String> answers = new ArrayList<String>();
        while (buffer.hasNext()) {
            String c = buffer.nextLine();
            answers.add(c);
        }
        file.close();
        buffer.close();
        return answers;
    }


}